' v5.5: v4a38/v4a39/v4a40 eliminados por codigo muerto.
' v4a38 siempre devolvia false, v4a40 solo lo envolvia y nadie
' llamaba a v4a39 (GetChannelClientId) ni a v4a40.
' El archivo se conserva vacio porque main.brs/29bd4.brs lo
' incluyen en el candado CRC y los XML lo referencian.
