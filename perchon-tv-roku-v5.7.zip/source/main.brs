sub Main()
    if not v4a43_Check() then return
    info = CreateObject("roAppInfo")
    screen = CreateObject("roSGScreen")
    m.port = CreateObject("roMessagePort")
    screen.setMessagePort(m.port)
    scene = screen.CreateScene("MainScene")
    screen.show()
    if scene.integrityFailed = true
        screen.close()
        return
    end if
    while true
        msg = wait(100, m.port)
        if scene.integrityFailed = true
            screen.close()
            exit while
        end if
        if type(msg) = "roSGScreenEvent" and msg.isScreenClosed()
            exit while
        end if
    end while
end sub

function v4a43_Check() as Boolean
    if v4a44_FileHash("pkg:/components/03fa1.brs") <> 519133470 then return false
    if v4a44_FileHash("pkg:/components/17c82.brs") <> 40260520 then return false
    if v4a44_FileHash("pkg:/components/29bd4.brs") <> -351232004 then return false
    if v4a44_FileHash("pkg:/components/41e70.brs") <> -1260847975 then return false
    if v4a44_FileHash("pkg:/components/5ac93.brs") <> 1055721497 then return false
    if v4a44_FileHash("pkg:/components/DebugScreen.xml") <> -1514507626 then return false
    if v4a44_FileHash("pkg:/components/HomeScreen.xml") <> 1217202404 then return false
    if v4a44_FileHash("pkg:/components/MainScene.xml") <> 78078855 then return false
    if v4a44_FileHash("pkg:/components/SettingsScreen.xml") <> 1179791977 then return false
    if v4a44_FileHash("pkg:/components/SetupScreen.xml") <> 905510859 then return false
    if v4a44_FileHash("pkg:/components/Tasks/68d2f.brs") <> 1951317998 then return false
    if v4a44_FileHash("pkg:/components/Tasks/7be14.brs") <> -892162044 then return false
    if v4a44_FileHash("pkg:/components/Tasks/8f036.brs") <> -145873336 then return false
    if v4a44_FileHash("pkg:/components/Tasks/9c751.brs") <> -98080957 then return false
    if v4a44_FileHash("pkg:/components/Tasks/ManifestProxy.xml") <> 1703824094 then return false
    if v4a44_FileHash("pkg:/components/Tasks/PortalTask.xml") <> 675790971 then return false
    if v4a44_FileHash("pkg:/components/Tasks/ProbeTask.xml") <> -320754519 then return false
    if v4a44_FileHash("pkg:/components/Tasks/SrtTask.xml") <> -1517232751 then return false
    if v4a44_FileHash("pkg:/components/Tasks/UpdateTask.brs") <> 1463964341 then return false
    if v4a44_FileHash("pkg:/components/Tasks/UpdateTask.xml") <> 57306589 then return false
    if v4a44_FileHash("pkg:/components/VideoPlayer.xml") <> -903056817 then return false
    if v4a44_FileHash("pkg:/manifest") <> 1081056186 then return false
    if v4a44_FileHash("pkg:/source/19d6e.brs") <> 642680813 then return false
    if v4a44_FileHash("pkg:/source/64be0.brs") <> -1369606072 then return false
    if v4a44_FileHash("pkg:/source/72ab4.brs") <> -388180172 then return false
    if v4a44_FileHash("pkg:/source/8ce21.brs") <> -1936185398 then return false
    if v4a44_FileHash("pkg:/source/a7f19.brs") <> 646528860 then return false
    if v4a44_FileHash("pkg:/source/b540f.brs") <> -1901163089 then return false
    if v4a44_FileHash("pkg:/source/c31d8.brs") <> 1398691210 then return false
    if v4a44_FileHash("pkg:/source/d29a3.brs") <> -1757548720 then return false
    if v4a44_FileHash("pkg:/source/e4b72.brs") <> -173036448 then return false
    if v4a44_FileHash("pkg:/source/f08ac.brs") <> 1781066939 then return false
    return true
end function

function v4a44_FileHash(path as String) as Integer
    ba = CreateObject("roByteArray")
    if not ba.ReadFile(path) then return -1
    return ba.GetCRC32()
end function
