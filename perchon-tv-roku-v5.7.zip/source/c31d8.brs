function Brand_Author() as String
    return "Perchon TV"
end function
function Brand_Copyright() as String
    return "Copyright 2026 Perchon TV"
end function
