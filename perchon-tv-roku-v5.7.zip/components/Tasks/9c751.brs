sub init()
    m.top.functionName = "PortalTask"
end sub
sub PortalTask()
    delays = [2000, 5000]
    lastErr = "async_fallo"
    for attempt = 1 to 3
        err = PortalAttempt()
        if err = ""
            return
        end if
        lastErr = err
        if attempt < 3 and PortalRetryable(err)
            sleepPort = CreateObject("roMessagePort")
            wait(delays[attempt - 1], sleepPort)
        else if attempt = 3
            m.top.error = lastErr
            return
        else
            m.top.error = lastErr
            return
        end if
    end for
    m.top.error = lastErr
end sub
function PortalRetryable(err as String) as Boolean
    if err = "timeout_20s" then return true
    if Left(err, 5) = "http_"
        code = Int(Val(Mid(err, 6)))
        if code >= 500 then return true
        if code = 0 then return true
    end if
    return false
end function
function PortalAttempt() as String
    req = CreateObject("roUrlTransfer")
    req.SetUrl(m.top.url)
    headers = m.top.headers
    if headers <> invalid
        for each k in headers
            req.AddHeader(k, headers[k])
        end for
    end if
    req.EnableEncodings(true)
    req.SetCertificatesFile("common:/certs/ca-bundle.crt")
    req.InitClientCertificates()
    port = CreateObject("roMessagePort")
    req.SetMessagePort(port)
    if not req.AsyncPostFromString(m.top.body)
        return "async_fallo"
    end if
    msg = wait(20000, port)
    if msg = invalid
        req.AsyncCancel()
        return "timeout_20s"
    end if
    if type(msg) <> "roUrlEvent"
        return "evento_inesperado"
    end if
    code = msg.GetResponseCode()
    if code <> 200
        return "http_" + code.ToStr()
    end if
    m.top.rawResp = msg.GetString()
    return ""
end function
