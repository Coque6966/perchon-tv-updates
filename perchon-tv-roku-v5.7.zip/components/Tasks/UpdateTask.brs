sub init()
    m.top.functionName = "UpdateTask"
end sub
sub UpdateTask()
    url = m.top.url
    if url = invalid or url = ""
        m.top.error = "sin_url"
        return
    end if
    req = CreateObject("roUrlTransfer")
    req.SetUrl(url)
    req.SetCertificatesFile("common:/certs/ca-bundle.crt")
    req.InitClientCertificates()
    req.EnableEncodings(true)
    port = CreateObject("roMessagePort")
    req.SetMessagePort(port)
    if not req.AsyncGetToString()
        m.top.error = "async_fallo"
        return
    end if
    msg = wait(10000, port)
    if msg = invalid
        req.AsyncCancel()
        m.top.error = "timeout_10s"
        return
    end if
    if type(msg) <> "roUrlEvent"
        m.top.error = "evento_inesperado"
        return
    end if
    code = msg.GetResponseCode()
    if code <> 200
        m.top.error = "http_" + code.ToStr()
        return
    end if
    m.top.body = msg.GetString()
end sub
