sub init()
    if not v5a01_Check2() then
        m.top.integrityFailed = true
        m.top.visible = false
        return
    end if
    m.setupScreen = m.top.FindNode("setupScreen")
    m.homeScreen  = m.top.FindNode("homeScreen")
    m.debugScreen = m.top.FindNode("debugScreen")
    m.debugScreen.ObserveField("action", "OnDebugAction")
    m.top.ObserveField("showDebug", "OnShowDebug")
    m.settingsScreen = m.top.FindNode("settingsScreen")
    m.settingsScreen.ObserveField("action", "OnSettingsAction")
    m.top.ObserveField("showSettings", "OnShowSettings")
    m.top.ObserveField("sessionStale", "OnSessionStale")
    if v4a26()
        ShowHome()
        if v4a49_SessionNeedsRenew()
            m.renewInBackground = true
            m.top.sessionStale = true
        end if
    else
        ShowSetup()
    end if
end sub
sub OnShowSettings(event as Object)
    if event.GetData() <> true then return
    m.top.showSettings = false
    m.homeScreen.halt = true
    m.settingsScreen.visible = true
    m.settingsScreen.SetFocus(true)
end sub
sub OnSettingsAction(event as Object)
    action = SafeStr(event.GetData())
    if action = "historyCleared"
        m.homeScreen.CallFunc("ClearHistoryMemory")
    else if action = "favoritesCleared"
        m.homeScreen.CallFunc("ClearFavoritesMemory")
    else if action = "close"
        m.settingsScreen.visible = false
        m.homeScreen.visible = true
        m.homeScreen.SetFocus(true)
    end if
end sub
sub ShowSetup()
    m.homeScreen.visible  = false
    m.setupScreen.visible = true
    m.setupScreen.SetFocus(true)
    m.setupScreen.status = "Conectando con Perchon TV..."
    m.renewing = false
    m.retryDelay = 0
    RegisterAccount()
end sub
sub ShowHome()
    m.setupScreen.visible = false
    m.homeScreen.visible = true
    m.homeScreen.SetFocus(true)
    m.homeScreen.start = true
end sub
sub OnShowDebug(event as Object)
    if event.GetData() <> true then return
    m.top.showDebug = false
    m.homeScreen.halt = true
    m.debugScreen.visible = true
    m.debugScreen.SetFocus(true)
end sub
sub OnDebugAction(event as Object)
    action = SafeStr(event.GetData())
    if action = "renew"
        CloseDebug()
        m.top.sessionStale = true
    else if action = "wipe"
        v4a24()
        CloseDebug()
        ShowSetup()
    else if action = "close"
        CloseDebug()
        ShowHome()
    end if
end sub
sub CloseDebug()
    m.debugScreen.visible = false
end sub
sub OnSessionStale(event as Object)
    if event.GetData() <> true then return
    m.top.sessionStale = false
    if m.renewing = true then return
    if not v4a26() then return
    RegisterAccount()
end sub
sub RegisterAccount()
    m.renewing = true
    v4a27()
    m.fp = v4a34()
    t = Api_OpTask("snToken", m.fp)
    if t = invalid
        RenewFailed("sin plantilla de alta")
        return
    end if
    if m.regTask <> invalid then m.regTask.control = "STOP"
    m.regTask = t
    m.regTask.ObserveField("rawResp", "OnRenewSnToken")
    m.regTask.ObserveField("error",   "OnRenewError")
    m.regTask.control = "RUN"
end sub
sub OnRenewSnToken(event as Object)
    data = Api_ParseOp(event.GetData())
    if data = invalid or not IsValidStr(data.snToken)
        RenewFailed("snToken sin token")
        return
    end if
    if IsValidStr(data.sn)
        m.newSn = data.sn
    else
        k = v4a21()
        m.newSn = v4a16(data.snToken + SafeStr(k.snSecret))
    end if
    m.newSnToken = data.snToken
    t = Api_OpTask("active", { snToken: m.newSnToken, sn: m.newSn })
    if t = invalid
        RenewFailed("sin plantilla de activacion")
        return
    end if
    if m.actTask <> invalid then m.actTask.control = "STOP"
    m.actTask = t
    m.actTask.ObserveField("rawResp", "OnRenewActive")
    m.actTask.ObserveField("error",   "OnRenewError")
    m.actTask.control = "RUN"
end sub
sub OnRenewActive(event as Object)
    data = Api_ParseOp(event.GetData())
    if data = invalid or not IsValidStr(data.userId)
        RenewFailed("active sin userId")
        return
    end if
    portalCode = "masnew"
    if data.portalCodeList <> invalid and data.portalCodeList.Count() > 0
        portalCode = data.portalCodeList[0].portalCode
    else if IsValidStr(data.portalCode)
        portalCode = data.portalCode
    end if
    id = v4a27()
    v4a23({
        sn:         m.newSn,
        snToken:    m.newSnToken,
        drmId:      id.drmId,
        reserve1:   id.reserve1,
        userId:     data.userId,
        userToken:  SafeStr(data.userToken),
        portalCode: portalCode,
        savedAt:    CreateObject("roDateTime").AsSeconds()
    })
    m.renewing = false
    if m.retryTimer <> invalid then m.retryTimer.control = "stop"
    ShowHome()
    if m.homeScreen.visible
        m.homeScreen.CallFunc("ReloadAfterRenew")
    end if
end sub
sub OnRenewError(event as Object)
    RenewFailed(SafeStr(event.GetData()))
end sub
sub RenewFailed(why as String)
    m.renewing = false
    if v4a26() then return
    if m.retryDelay = invalid or m.retryDelay < 5
        m.retryDelay = 5
    else
        m.retryDelay = m.retryDelay * 2
        if m.retryDelay > 60 then m.retryDelay = 60
    end if
    m.setupScreen.status = "Sin conexion. Reintentando en " + m.retryDelay.ToStr() + " s..."
    if m.retryTimer = invalid
        m.retryTimer = CreateObject("roSGNode", "Timer")
        m.retryTimer.repeat = false
        m.retryTimer.ObserveField("fire", "OnRetryTick")
    end if
    m.retryTimer.control = "stop"
    m.retryTimer.duration = m.retryDelay
    m.retryTimer.control = "start"
end sub
sub OnRetryTick(event as Object)
    if v4a26() then return
    m.setupScreen.status = "Conectando con Perchon TV..."
    RegisterAccount()
end sub
function v5a01_Check2() as Boolean
    if v5a02_FileHash("pkg:/source/72ab4.brs") <> -388180172 then return false
    if v5a02_FileHash("pkg:/source/8ce21.brs") <> -1936185398 then return false
    if v5a02_FileHash("pkg:/source/e4b72.brs") <> -173036448 then return false
    if v5a02_FileHash("pkg:/source/a7f19.brs") <> 646528860 then return false
    if v5a02_FileHash("pkg:/source/64be0.brs") <> -1369606072 then return false
    if v5a02_FileHash("pkg:/components/Tasks/9c751.brs") <> -98080957 then return false
    if v5a02_FileHash("pkg:/components/Tasks/68d2f.brs") <> 1951317998 then return false
    return true
end function
function v5a02_FileHash(path as String) as Integer
    ba = CreateObject("roByteArray")
    if not ba.ReadFile(path) then return -1
    return ba.GetCRC32()
end function
