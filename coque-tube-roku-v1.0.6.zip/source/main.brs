sub Main()
    if not TubeCheck() then return
    screen = CreateObject("roSGScreen")
    m.port = CreateObject("roMessagePort")
    screen.setMessagePort(m.port)
    scene = screen.CreateScene("MainScene")
    screen.show()
    while true
        msg = wait(100, m.port)
        if type(msg) = "roSGScreenEvent" and msg.isScreenClosed()
            exit while
        end if
    end while
end sub

function TubeCheck() as Boolean
    if TubeHash("pkg:/components/MainScene.brs") <> -1434605211 then return false
    if TubeHash("pkg:/components/MainScene.xml") <> 44714190 then return false
    if TubeHash("pkg:/components/Tasks/YtTask.xml") <> 880616073 then return false
    if TubeHash("pkg:/components/Tasks/ytget.brs") <> -783107568 then return false
    if TubeHash("pkg:/components/Tasks/UpdateTask.brs") <> 1463964341 then return false
    if TubeHash("pkg:/components/Tasks/UpdateTask.xml") <> 57306589 then return false
    if TubeHash("pkg:/components/Tasks/HistoryTask.brs") <> 597379031 then return false
    if TubeHash("pkg:/components/Tasks/HistoryTask.xml") <> -2060696516 then return false
    if TubeHash("pkg:/manifest") <> 1111681258 then return false
    return true
end function

function TubeHash(path as String) as Integer
    ba = CreateObject("roByteArray")
    if not ba.ReadFile(path) then return -1
    return ba.GetCRC32()
end function
