sub init()
    m.statusLabel = m.top.FindNode("statusLabel")
    m.noticeLabel = m.top.FindNode("noticeLabel")
    m.noticeTimer = m.top.FindNode("noticeTimer")
    m.bufferTimer = m.top.FindNode("bufferTimer")
    m.rowList = m.top.FindNode("rowList")
    m.player = m.top.FindNode("player")
    m.detailGroup = m.top.FindNode("detailGroup")
    m.detailPoster = m.top.FindNode("detailPoster")
    m.detailTitle = m.top.FindNode("detailTitle")
    m.detailMeta = m.top.FindNode("detailMeta")
    m.detailDesc = m.top.FindNode("detailDesc")
    m.detailRowList = m.top.FindNode("detailRowList")
    m.rowList.ObserveField("rowItemSelected", "OnRowItemSelected")
    m.detailRowList.ObserveField("rowItemSelected", "OnDetailRowSelected")
    m.player.ObserveField("state", "OnPlayerState")
    m.noticeTimer.ObserveField("fire", "OnNoticeTimer")
    m.bufferTimer.ObserveField("fire", "OnBufferTimer")
    m.tubeTask = invalid
    m.tubeReq = ""
    m.tubeStage = 0
    m.tubeItem = invalid
    m.tubeTerm = ""
    m.tubeSearchText = ""
    m.tubeSearchCancel = false
    m.tubeSearchDlg = invalid
    m.lastTubeSearch = invalid
    m.tubeBusy = false
    m.items = []
    m.liveItems = []
    m.historyItems = []
    m.historyRow = -1
    m.videoRow = 1
    m.liveRow = -1
    m.historyTask = invalid
    m.historySaveTask = invalid
    m.playing = false
    m.playStarted = false
    m.detailOpen = false
    m.detailItem = invalid
    m.detailData = invalid
    m.detailStage = 0
    m.detailRelated = []
    m.returnToDetail = false
    m.tubeRefreshUsed = false
    m.liveEdgeDone = false
    m.updateFallbackUsed = false
    m.rowList.SetFocus(true)
    TubeLoadHistory()
    TubeLoadTrending()
    TubeCheckUpdate()
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false
    if key = "back"
        if m.playing
            ClosePlayer()
            return true
        end if
        if m.detailOpen
            CloseDetail()
            return true
        end if
        if m.tubeBusy and (m.tubeReq = "detail" or m.tubeReq = "stream")
            if m.tubeTask <> invalid then m.tubeTask.control = "STOP"
            m.tubeTask = invalid
            m.tubeBusy = false
            return true
        end if
        return false
    end if
    return false
end function

sub OnRowItemSelected(event as Object)
    sel = event.GetData()
    if sel = invalid or sel.Count() < 2 then return
    if sel[0] = 0
        ShowTubeSearchDialog()
        return
    end if
    if m.historyRow >= 0 and sel[0] = m.historyRow
        TubeOpenHistoryItem(sel[1])
    else if sel[0] = m.videoRow
        TubeOpenItem(sel[1])
    else if m.liveRow >= 0 and sel[0] = m.liveRow
        TubeOpenLiveItem(sel[1])
    end if
end sub

sub OnDetailRowSelected(event as Object)
    sel = event.GetData()
    if sel = invalid or sel.Count() < 2 then return
    if sel[0] = 0
        TubePlayDetail()
    else if sel[0] = 1
        idx = sel[1]
        if idx >= 0 and idx < m.detailRelated.Count() then TubeOpenDetail(m.detailRelated[idx])
    end if
end sub

sub OnPlayerState(event as Object)
    st = SafeStr(event.GetData())
    if st = "playing"
        m.playStarted = true
        m.bufferTimer.control = "stop"
        ' En vivo: arrancar en el borde -3 s (como Tube20 en Android).
        ' El Video de Roku no acepta playStart en vivo, asi que al primer
        ' "playing" se busca a duracion-3 una sola vez por video. Si el
        ' nodo no permite el seek en vivo, Roku lo ignora y queda en el
        ' borde que da el manifiesto HLS.
        if TubeIsLive(m.tubeItem) and not m.liveEdgeDone
            m.liveEdgeDone = true
            dur = m.player.duration
            if dur <> invalid and dur > 10 then m.player.seek(dur - 3)
        end if
    else if st = "error"
        m.bufferTimer.control = "stop"
        if m.playing then TubeRefreshOrAdvance()
    else if st = "finished"
        if m.playing then ClosePlayer()
    end if
end sub

sub OnBufferTimer(event as Object)
    if m.playing and not m.playStarted then TubeAdvance()
end sub

sub OnNoticeTimer(event as Object)
    m.noticeLabel.visible = false
end sub

sub ShowNotice(msg as String)
    m.noticeLabel.text = msg
    m.noticeLabel.visible = true
    m.noticeTimer.control = "start"
end sub

sub ClosePlayer()
    m.playing = false
    m.playStarted = false
    m.bufferTimer.control = "stop"
    if m.tubeBusy and m.tubeReq = "stream"
        if m.tubeTask <> invalid then m.tubeTask.control = "STOP"
        m.tubeTask = invalid
        m.tubeBusy = false
    end if
    m.player.control = "stop"
    m.player.visible = false
    if m.returnToDetail and m.detailItem <> invalid
        m.returnToDetail = false
        TubeRenderDetail()
        return
    end if
    m.returnToDetail = false
    m.detailOpen = false
    m.detailGroup.visible = false
    m.rowList.visible = true
    if m.items.Count() > 0 then TubeBuildRows()
    m.rowList.SetFocus(true)
end sub

sub CloseDetail()
    m.detailOpen = false
    m.returnToDetail = false
    if m.tubeBusy and (m.tubeReq = "detail" or m.tubeReq = "stream")
        if m.tubeTask <> invalid then m.tubeTask.control = "STOP"
        m.tubeTask = invalid
        m.tubeBusy = false
    end if
    m.detailGroup.visible = false
    m.rowList.visible = true
    if m.items.Count() > 0 then TubeBuildRows()
    m.rowList.SetFocus(true)
end sub

sub TubeLoadTrending()
    m.tubeReq = "trending"
    m.tubeStage = 1
    m.tubeTerm = ""
    m.statusLabel.text = "Cargando tendencias..."
    m.statusLabel.visible = true
    m.rowList.visible = false
    TubeFire(TubeTrendingUrl())
end sub

function TubeTrendingUrl() as String
    if m.tubeStage = 2 then return "https://pipedapi.ducks.party/trending?region=MX"
    if m.tubeStage = 3 then return "https://yt.chocolatemoo53.com/api/v1/trending?type=Default&region=MX"
    return "https://api.piped.private.coffee/trending?region=MX"
end function

sub TubeSearch(term as String)
    m.tubeTerm = term
    m.lastTubeSearch = term
    m.tubeReq = "search"
    m.tubeStage = 1
    m.statusLabel.text = "Buscando: " + term
    m.statusLabel.visible = true
    m.rowList.visible = false
    TubeFire(TubeSearchUrl())
end sub

function TubeSearchUrl() as String
    enc = TubeUrlEncode(m.tubeTerm)
    if m.tubeStage = 2 then return "https://pipedapi.ducks.party/search?q=" + enc + "&filter=videos"
    if m.tubeStage = 3 then return "https://yt.chocolatemoo53.com/api/v1/search?q=" + enc + "&type=video"
    return "https://api.piped.private.coffee/search?q=" + enc + "&filter=videos"
end function

sub TubeOpenItem(idx as Integer)
    if idx < 0 or idx >= m.items.Count() then return
    TubeOpenDetail(m.items[idx])
end sub

sub TubeOpenHistoryItem(idx as Integer)
    if idx < 0 or idx >= m.historyItems.Count() then return
    TubeOpenDetail(m.historyItems[idx])
end sub

sub TubeOpenLiveItem(idx as Integer)
    if idx < 0 or idx >= m.liveItems.Count() then return
    TubeOpenDetail(m.liveItems[idx])
end sub

sub TubeOpenDetail(it as Object)
    if it = invalid then return
    vid = SafeStr(it._tubeVideoId)
    if vid = "" then return
    m.tubeItem = it
    m.tubeRefreshUsed = false
    m.liveEdgeDone = false
    m.tubeReq = "detail"
    if TubeIsLive(it)
        m.tubeStage = 3
    else
        m.tubeStage = 1
    end if
    ShowNotice("Cargando video...")
    TubeFire(TubeStreamUrl())
end sub

sub TubeHandleDetail(data as Object)
    if Type(data) <> "roAssociativeArray"
        TubeAdvance()
        return
    end if
    if data.error <> invalid
        TubeAdvance()
        return
    end if
    TubeShowDetail(m.tubeItem, data, m.tubeStage)
end sub

sub TubeShowDetail(it as Object, data as Object, stage as Integer)
    if it = invalid then return
    m.detailItem = it
    m.detailData = data
    m.detailStage = stage
    m.detailRelated = []
    if data <> invalid and stage < 4
        rel = invalid
        if stage < 3
            if data.relatedStreams <> invalid then rel = data.relatedStreams
        else
            if data.recommendedVideos <> invalid then rel = data.recommendedVideos
        end if
        if rel <> invalid then m.detailRelated = TubeMapItems(rel)
    end if
    TubeRenderDetail()
end sub

sub TubeRenderDetail()
    it = m.detailItem
    if it = invalid then return
    data = m.detailData
    m.detailOpen = true
    m.detailPoster.uri = SafeStr(it.posterUrl)
    ttl = SafeStr(it.name)
    ch = ""
    vw = 0
    pub = ""
    dsc = ""
    if data <> invalid and m.detailStage < 4
        if data.title <> invalid and SafeStr(data.title) <> "" then ttl = SafeStr(data.title)
        if m.detailStage < 3
            if data.uploader <> invalid then ch = SafeStr(data.uploader)
            if data.views <> invalid then vw = AsInt(data.views)
            if data.uploadDate <> invalid then pub = SafeStr(data.uploadDate)
        else
            if data.author <> invalid then ch = SafeStr(data.author)
            if data.viewCount <> invalid then vw = AsInt(data.viewCount)
            if data.publishedText <> invalid then pub = SafeStr(data.publishedText)
        end if
        if data.description <> invalid then dsc = SafeStr(data.description)
    end if
    if ch = "" and it._tubeChannel <> invalid then ch = SafeStr(it._tubeChannel)
    if vw = 0 and it._tubeViews <> invalid then vw = AsInt(it._tubeViews)
    if pub = "" and it._tubePublished <> invalid then pub = SafeStr(it._tubePublished)
    if dsc = "" and it._tubeDesc <> invalid then dsc = SafeStr(it._tubeDesc)
    m.detailTitle.text = ttl
    meta = ""
    if ch <> "" then meta = ch
    if vw > 0
        vs = TubeFormatViews(vw) + " vistas"
        if meta <> ""
            meta = meta + " · " + vs
        else
            meta = vs
        end if
    end if
    if pub <> ""
        if meta <> ""
            meta = meta + " · " + pub
        else
            meta = pub
        end if
    end if
    if TubeIsLive(it)
        if meta <> ""
            meta = "[EN VIVO] · " + meta
        else
            meta = "[EN VIVO]"
        end if
    end if
    m.detailMeta.text = meta
    if Len(dsc) > 400 then dsc = Left(dsc, 400) + "..."
    m.detailDesc.text = dsc
    root = CreateObject("roSGNode", "ContentNode")
    playRow = CreateObject("roSGNode", "ContentNode")
    playRow.title = "Reproducir"
    pc = CreateObject("roSGNode", "ContentNode")
    pc.title = "Reproducir"
    pc.hdPosterUrl = SafeStr(it.posterUrl)
    pc.description = "Ver ahora"
    playRow.AppendChild(pc)
    root.AppendChild(playRow)
    if m.detailRelated.Count() > 0
        rRow = CreateObject("roSGNode", "ContentNode")
        rRow.title = "Relacionados"
        for each rit in m.detailRelated
            c = CreateObject("roSGNode", "ContentNode")
            c.title = TubeItemTitle(rit)
            c.hdPosterUrl = rit.posterUrl
            c.description = rit.name
            if rit._tubeDuration <> invalid and rit._tubeDuration > 0 then c.length = rit._tubeDuration
            rRow.AppendChild(c)
        end for
        root.AppendChild(rRow)
    end if
    m.detailRowList.content = root
    m.rowList.visible = false
    m.statusLabel.visible = false
    m.detailGroup.visible = true
    m.detailRowList.SetFocus(true)
end sub

sub TubePlayDetail()
    if m.detailItem = invalid then return
    m.tubeItem = m.detailItem
    m.tubeRefreshUsed = false
    m.liveEdgeDone = false
    m.returnToDetail = true
    if TubeIsLive(m.detailItem)
        m.tubeReq = "stream"
        m.tubeStage = 4
        ShowNotice("Cargando video...")
        TubeFire(TubeStreamUrl())
        return
    end if
    if m.detailData = invalid
        m.tubeReq = "stream"
        m.tubeStage = 1
        ShowNotice("Cargando video...")
        TubeFire(TubeStreamUrl())
        return
    end if
    m.tubeReq = "stream"
    m.tubeStage = m.detailStage
    TubeHandleStream(m.detailData)
end sub

function TubeStreamUrl() as String
    vid = SafeStr(m.tubeItem._tubeVideoId)
    if m.tubeStage = 2 then return "https://pipedapi.ducks.party/streams/" + vid
    if m.tubeStage = 3 then return "https://yt.chocolatemoo53.com/api/v1/videos/" + vid
    if m.tubeStage = 4 then return "http://192.168.100.84:8766/tube-live?id=" + vid
    return "https://api.piped.private.coffee/streams/" + vid
end function

sub TubeFire(url as String)
    if m.tubeTask <> invalid then m.tubeTask.control = "STOP"
    m.tubeTask = CreateObject("roSGNode", "YtTask")
    m.tubeTask.ObserveField("response", "OnTubeResp")
    m.tubeTask.ObserveField("error", "OnTubeErr")
    m.tubeTask.url = url
    if (m.tubeReq = "stream" or m.tubeReq = "detail") and m.tubeStage = 4
        m.tubeTask.timeout = 30000
    else
        m.tubeTask.timeout = 5000
    end if
    m.tubeBusy = true
    m.tubeTask.control = "RUN"
end sub

sub OnTubeResp(event as Object)
    if not m.tubeBusy then return
    m.tubeBusy = false
    raw = event.GetData()
    data = ParseJSON(SafeStr(raw))
    if data = invalid
        TubeAdvance()
        return
    end if
    if m.tubeReq = "stream"
        TubeHandleStream(data)
    else if m.tubeReq = "detail"
        TubeHandleDetail(data)
    else if m.tubeReq = "trending"
        TubeHandleList(data)
    else if m.tubeReq = "search"
        TubeHandleList(data)
    end if
end sub

sub OnTubeErr(event as Object)
    if not m.tubeBusy then return
    m.tubeBusy = false
    err = SafeStr(event.GetData())
    ' 403 al pedir las URLs: las URLs firmadas de Piped/Invidious expiran.
    ' Un solo reintento con URLs frescas de la MISMA fuente antes de
    ' pasar a la siguiente (como Tube20 en Android: 1 reintento por video).
    if err = "http_403" and TubeCanRefresh()
        TubeRefreshSameStage()
        return
    end if
    TubeAdvance()
end sub

' Se puede re-pedir URLs frescas de la misma fuente una sola vez por video,
' solo para reproduccion (stream) en las etapas con URL firmada (1-3).
' La etapa 4 es el relay de la PC, que ya sirve URLs frescas cada vez.
function TubeCanRefresh() as Boolean
    if m.tubeRefreshUsed = true then return false
    if m.tubeReq <> "stream" then return false
    if m.tubeStage < 1 or m.tubeStage > 3 then return false
    return true
end function

sub TubeRefreshSameStage()
    m.tubeRefreshUsed = true
    m.playStarted = false
    m.bufferTimer.control = "start"
    TubeFire(TubeStreamUrl())
end sub

sub TubeRefreshOrAdvance()
    if TubeCanRefresh()
        TubeRefreshSameStage()
        return
    end if
    TubeAdvance()
end sub

sub TubeAdvance()
    if m.tubeStage < 4
        m.tubeStage = m.tubeStage + 1
        if m.tubeReq = "stream"
            TubeFire(TubeStreamUrl())
        else if m.tubeReq = "detail"
            TubeFire(TubeStreamUrl())
        else if m.tubeReq = "trending"
            TubeFire(TubeTrendingUrl())
        else if m.tubeReq = "search"
            TubeFire(TubeSearchUrl())
        end if
        return
    end if
    if m.tubeReq = "stream"
        ClosePlayer()
        ShowNotice("No se pudo cargar este video de Tube, intenta otro")
    else if m.tubeReq = "detail"
        ShowNotice("No se pudo cargar este video de Tube, intenta otro")
    else if m.tubeReq = "trending" or m.tubeReq = "search"
        if m.rowList.content = invalid
            m.statusLabel.text = "Sin servicio de Tube, intenta más tarde"
            m.statusLabel.visible = true
        else
            ShowNotice("Sin servicio de Tube, intenta más tarde")
        end if
    end if
end sub

sub TubeHandleStream(data as Object)
    if Type(data) <> "roAssociativeArray"
        TubeAdvance()
        return
    end if
    if data.error <> invalid
        TubeAdvance()
        return
    end if
    if m.tubeStage = 4
        u = SafeStr(data.url)
        if u <> ""
            fmt = SafeStr(data.format)
            if fmt = "" then fmt = "hls"
            TubeStartPlayback(u, fmt, "")
            return
        end if
        TubeAdvance()
        return
    end if
    if m.tubeStage < 3
        streams = data.videoStreams
        if streams <> invalid
            for each s in streams
                vo = s.videoOnly
                if SafeStr(s.quality) = "360p" and (vo = invalid or vo = false)
                    TubeStartPlayback(SafeStr(s.url), "mp4", SafeStr(data.duration))
                    return
                end if
            end for
        end if
        if SafeStr(data.hls) <> ""
            TubeStartPlayback(SafeStr(data.hls), "hls", SafeStr(data.duration))
            return
        end if
        TubeAdvance()
        return
    end if
    fmts = data.formatStreams
    if fmts <> invalid
        for each f in fmts
            if AsInt(f.itag) = 18
                TubeStartPlayback(SafeStr(f.url), "mp4", SafeStr(data.lengthSeconds))
                return
            end if
        end for
    end if
    if SafeStr(data.hlsUrl) <> ""
        TubeStartPlayback(SafeStr(data.hlsUrl), "hls", SafeStr(data.lengthSeconds))
        return
    end if
    TubeAdvance()
end sub

sub TubeHandleList(data as Object)
    raw = []
    if Type(data) = "roArray"
        raw = data
    else if Type(data) = "roAssociativeArray"
        if data.items <> invalid and Type(data.items) = "roArray"
            raw = data.items
        end if
    end if
    items = TubeMapItems(raw)
    if items.Count() = 0
        TubeAdvance()
        return
    end if
    m.items = items
    TubeBuildRows()
    m.rowList.SetFocus(true)
end sub

sub TubeBuildRows()
    if m.items.Count() = 0 then return
    root = CreateObject("roSGNode", "ContentNode")
    searchRow = CreateObject("roSGNode", "ContentNode")
    searchRow.title = "Buscar"
    searchItem = CreateObject("roSGNode", "ContentNode")
    searchItem.title = "Buscar en Tube"
    searchItem.hdPosterUrl = "pkg:/images/search_tile.png"
    searchItem.description = "Buscar videos de YouTube"
    searchRow.AppendChild(searchItem)
    root.AppendChild(searchRow)
    m.historyRow = -1
    m.videoRow = 1
    m.liveRow = -1
    if m.historyItems.Count() > 0
        m.historyRow = 1
        m.videoRow = 2
        hRow = CreateObject("roSGNode", "ContentNode")
        hRow.title = "Historial"
        for each it in m.historyItems
            c = CreateObject("roSGNode", "ContentNode")
            c.title = TubeItemTitle(it)
            c.hdPosterUrl = it.posterUrl
            c.description = it.name
            hRow.AppendChild(c)
        end for
        root.AppendChild(hRow)
    end if
    vidRow = CreateObject("roSGNode", "ContentNode")
    if m.tubeReq = "search"
        vidRow.title = "Resultados: " + m.tubeTerm
    else
        vidRow.title = "Tendencias MX"
    end if
    for each it in m.items
        c = CreateObject("roSGNode", "ContentNode")
        c.title = TubeItemTitle(it)
        c.hdPosterUrl = it.posterUrl
        c.description = it.name
        if it._tubeDuration <> invalid and it._tubeDuration > 0 then c.length = it._tubeDuration
        vidRow.AppendChild(c)
    end for
    root.AppendChild(vidRow)
    if m.tubeReq <> "search"
        m.liveItems = []
        for each it in m.items
            if TubeIsLive(it) then m.liveItems.Push(it)
        end for
        if m.liveItems.Count() > 0
            m.liveRow = m.videoRow + 1
            lRow = CreateObject("roSGNode", "ContentNode")
            lRow.title = "En vivo"
            for each it in m.liveItems
                c = CreateObject("roSGNode", "ContentNode")
                c.title = TubeItemTitle(it)
                c.hdPosterUrl = it.posterUrl
                c.description = it.name
                lRow.AppendChild(c)
            end for
            root.AppendChild(lRow)
        end if
    end if
    m.rowList.content = root
    m.statusLabel.visible = false
    m.rowList.visible = true
end sub

function TubeMapItems(raw as Object) as Object
    out = []
    if raw = invalid then return out
    if Type(raw) <> "roArray" then return out
    for each r in raw
        one = TubeMapOne(r)
        if one <> invalid then out.Push(one)
    end for
    return out
end function

function TubeMapOne(r as Object) as Object
    if r = invalid or Type(r) <> "roAssociativeArray" then return invalid
    vid = ""
    if r.videoId <> invalid then vid = SafeStr(r.videoId)
    if vid = "" and r.url <> invalid
        u = SafeStr(r.url)
        p = Instr(1, u, "v=")
        if p > 0
            vid = Mid(u, p + 2)
            amp = Instr(1, vid, "&")
            if amp > 0 then vid = Left(vid, amp - 1)
        end if
    end if
    if vid = "" then return invalid
    thumb = ""
    if r.thumbnail <> invalid then thumb = SafeStr(r.thumbnail)
    if thumb = "" and r.videoThumbnails <> invalid then thumb = TubePickThumb(r.videoThumbnails)
    if thumb = "" and r.thumbnails <> invalid then thumb = TubePickThumb(r.thumbnails)
    title = SafeStr(r.title)
    if title = "" then title = "Video"
    dur = 0
    if r.duration <> invalid then dur = AsInt(r.duration)
    if r.lengthSeconds <> invalid then dur = AsInt(r.lengthSeconds)
    live = false
    if dur = -1 then live = true
    if r.liveNow <> invalid and r.liveNow = true then live = true
    if r.isLive <> invalid and r.isLive = true then live = true
    ch = ""
    if r.uploaderName <> invalid then ch = SafeStr(r.uploaderName)
    if ch = "" and r.author <> invalid then ch = SafeStr(r.author)
    if ch = "" and r.uploader <> invalid then ch = SafeStr(r.uploader)
    vw = 0
    if r.views <> invalid then vw = AsInt(r.views)
    if vw = 0 and r.viewCount <> invalid then vw = AsInt(r.viewCount)
    pub = ""
    if r.uploadedDate <> invalid then pub = SafeStr(r.uploadedDate)
    if pub = "" and r.publishedText <> invalid then pub = SafeStr(r.publishedText)
    if pub = "" and r.uploadDate <> invalid then pub = SafeStr(r.uploadDate)
    dsc = ""
    if r.description <> invalid then dsc = SafeStr(r.description)
    return { name: title, posterUrl: thumb, id: vid, _tube: true, _tubeVideoId: vid, _tubeDuration: dur, _tubeLive: live, _tubeChannel: ch, _tubeViews: vw, _tubePublished: pub, _tubeDesc: dsc }
end function

function TubePickThumb(thumbs as Object) as String
    if thumbs = invalid or Type(thumbs) <> "roArray" then return ""
    best = ""
    for each t in thumbs
        if Type(t) = "roAssociativeArray"
            u = SafeStr(t.url)
            qual = SafeStr(t.quality)
            if u <> ""
                if qual = "high" then return u
                if best = "" then best = u
            end if
        end if
    end for
    return best
end function

function TubeIsLive(it as Object) as Boolean
    if it = invalid then return false
    if it._tubeLive <> invalid and it._tubeLive = true then return true
    return false
end function

function TubeFormatDuration(sec as Integer) as String
    if sec <= 0 then return ""
    mm = Int(sec / 60)
    ss = sec mod 60
    ssStr = ss.ToStr()
    if ss < 10 then ssStr = "0" + ssStr
    if mm >= 60
        hh = Int(mm / 60)
        mm2 = mm mod 60
        mmStr = mm2.ToStr()
        if mm2 < 10 then mmStr = "0" + mmStr
        return hh.ToStr() + ":" + mmStr + ":" + ssStr
    end if
    return mm.ToStr() + ":" + ssStr
end function

function TubeFormatViews(n as Integer) as String
    if n >= 1000000
        tenths = Int(n / 100000)
        whole = Int(tenths / 10)
        frac = tenths mod 10
        if frac = 0 then return whole.ToStr() + " M"
        return whole.ToStr() + "." + frac.ToStr() + " M"
    end if
    if n >= 1000
        return Int(n / 1000).ToStr() + " mil"
    end if
    return n.ToStr()
end function

function TubeItemTitle(it as Object) as String
    if it = invalid then return ""
    nm = SafeStr(it.name)
    if TubeIsLive(it)
        vs = ""
        if it._tubeViews <> invalid and AsInt(it._tubeViews) > 0 then vs = TubeFormatViews(AsInt(it._tubeViews)) + " vistas · "
        return "[EN VIVO] " + vs + nm
    end if
    parts = ""
    if it._tubeDuration <> invalid and AsInt(it._tubeDuration) > 0 then parts = TubeFormatDuration(AsInt(it._tubeDuration))
    if it._tubeViews <> invalid and AsInt(it._tubeViews) > 0
        vs = TubeFormatViews(AsInt(it._tubeViews)) + " vistas"
        if parts <> ""
            parts = parts + " · " + vs
        else
            parts = vs
        end if
    end if
    if parts <> "" then return parts + " · " + nm
    return nm
end function

sub TubeStartPlayback(url as String, fmt as String, dur as String)
    if url = "" then ShowNotice("No se pudo cargar este video de Tube") : return
    TubeSaveHistoryItem(m.tubeItem)
    m.playing = true
    m.playStarted = false
    m.returnToDetail = m.detailOpen
    m.detailOpen = false
    m.detailGroup.visible = false
    m.rowList.visible = false
    m.statusLabel.visible = false
    m.noticeLabel.visible = false
    c = CreateObject("roSGNode", "ContentNode")
    c.url = url
    c.streamformat = fmt
    c.title = SafeStr(m.tubeItem.name)
    if TubeIsLive(m.tubeItem) then c.live = true
    if dur <> "" and Val(dur) > 0 then c.length = Int(Val(dur))
    m.player.content = c
    m.player.visible = true
    m.player.control = "play"
    m.player.SetFocus(true)
    m.bufferTimer.control = "start"
end sub

sub TubeLoadHistory()
    t = CreateObject("roSGNode", "HistoryTask")
    if t = invalid then return
    t.ObserveField("result", "OnHistoryResult")
    t.ObserveField("error", "OnHistoryError")
    m.historyTask = t
    t.op = "load"
    t.control = "RUN"
end sub

sub OnHistoryResult(event as Object)
    raw = SafeStr(event.GetData())
    arr = ParseJSON(raw)
    items = []
    if arr <> invalid and Type(arr) = "roArray"
        for each s in arr
            if s <> invalid and Type(s) = "roAssociativeArray"
                vid = SafeStr(s.id)
                if vid <> ""
                    lv = false
                    if s.live <> invalid and s.live = true then lv = true
                    items.Push({ name: SafeStr(s.title), posterUrl: SafeStr(s.thumb), id: vid, _tube: true, _tubeVideoId: vid, _tubeDuration: 0, _tubeLive: lv })
                end if
            end if
        end for
    end if
    m.historyItems = items
    if not m.playing and not m.detailOpen and m.items.Count() > 0 then TubeBuildRows()
end sub

sub OnHistoryError(event as Object)
    ' Sin historial guardado: la app sigue normal, sin fila de historial.
end sub

sub TubeSaveHistoryItem(it as Object)
    if it = invalid then return
    vid = SafeStr(it._tubeVideoId)
    if vid = "" then return
    cleaned = []
    for each old in m.historyItems
        if SafeStr(old._tubeVideoId) <> vid then cleaned.Push(old)
    end for
    cleaned.Unshift(it)
    while cleaned.Count() > 20
        cleaned.Pop()
    end while
    m.historyItems = cleaned
    t = CreateObject("roSGNode", "HistoryTask")
    if t = invalid then return
    t.ObserveField("error", "OnHistoryError")
    m.historySaveTask = t
    t.op = "save"
    t.data = FormatJSON({ id: vid, title: SafeStr(it.name), thumb: SafeStr(it.posterUrl), live: TubeIsLive(it) })
    t.control = "RUN"
end sub

sub ShowTubeSearchDialog()
    dlg = CreateObject("roSGNode", "KeyboardDialog")
    dlg.title = "Buscar en Tube (escribe y pulsa Buscar o Back)"
    dlg.buttons = ["Buscar", "Cancelar"]
    m.tubeSearchText = ""
    if m.lastTubeSearch <> invalid
        dlg.text = m.lastTubeSearch
        m.tubeSearchText = m.lastTubeSearch
    end if
    m.tubeSearchCancel = false
    m.tubeSearchDlg = dlg
    dlg.ObserveField("text", "OnTubeSearchText")
    dlg.ObserveField("buttonSelected", "OnTubeSearchButton")
    dlg.ObserveField("wasClosed", "OnTubeSearchClosed")
    m.top.dialog = dlg
end sub

sub OnTubeSearchText(event as Object)
    m.tubeSearchText = SafeStr(event.GetData())
end sub

sub OnTubeSearchButton(event as Object)
    idx = event.GetData()
    if idx = 1 then m.tubeSearchCancel = true
    if m.tubeSearchDlg <> invalid then m.tubeSearchDlg.close = true
end sub

sub OnTubeSearchClosed(event as Object)
    term = m.tubeSearchText
    cancel = m.tubeSearchCancel
    m.tubeSearchDlg = invalid
    m.rowList.SetFocus(true)
    if not cancel and term <> invalid and Len(term) > 0 then TubeSearch(term)
end sub

function TubeUrlEncode(s as String) as String
    out = ""
    for i = 1 to Len(s)
        ch = Mid(s, i, 1)
        code = Asc(ch)
        if (code >= 48 and code <= 57) or (code >= 65 and code <= 90) or (code >= 97 and code <= 122) or ch = "-" or ch = "_" or ch = "." or ch = "~"
            out = out + ch
        else if ch = " "
            out = out + "%20"
        else if ch = "á"
            out = out + "%C3%A1"
        else if ch = "é"
            out = out + "%C3%A9"
        else if ch = "í"
            out = out + "%C3%AD"
        else if ch = "ó"
            out = out + "%C3%B3"
        else if ch = "ú"
            out = out + "%C3%BA"
        else if ch = "ñ"
            out = out + "%C3%B1"
        else if ch = "Á"
            out = out + "%C3%81"
        else if ch = "É"
            out = out + "%C3%89"
        else if ch = "Í"
            out = out + "%C3%8D"
        else if ch = "Ó"
            out = out + "%C3%93"
        else if ch = "Ú"
            out = out + "%C3%9A"
        else if ch = "Ñ"
            out = out + "%C3%91"
        else if ch = "ü"
            out = out + "%C3%BC"
        else if ch = "¡"
            out = out + "%C2%A1"
        else if ch = "¿"
            out = out + "%C2%BF"
        else if code >= 32 and code < 128
            out = out + "%" + TubeHex2(code)
        else
            out = out + ch
        end if
    end for
    return out
end function

function TubeHex2(n as Integer) as String
    digits = "0123456789ABCDEF"
    return Mid(digits, Int(n / 16) + 1, 1) + Mid(digits, (n mod 16) + 1, 1)
end function

sub TubeCheckUpdate()
    if m.updateTask <> invalid then m.updateTask.control = "STOP"
    t = CreateObject("roSGNode", "UpdateTask")
    if t = invalid then return
    ' Manifiesto en GitHub Pages (sin depender de la PC); si falla, el
    ' error cae al servidor de casa :8766 como respaldo.
    t.url = "https://coque6966.github.io/perchon-tv-updates/coque-tube-roku-update.json"
    t.ObserveField("body", "OnTubeUpdateBody")
    t.ObserveField("error", "OnTubeUpdateError")
    m.updateTask = t
    m.updateFallbackUsed = false
    t.control = "RUN"
end sub

sub OnTubeUpdateBody(event as Object)
    mfest = ParseJSON(SafeStr(event.GetData()))
    if mfest = invalid then return
    ver = SafeStr(mfest.version)
    if ver = "" then return
    if TubeVersionIsNewer(ver, TubeCurrentVersion())
        ShowNotice("Actualización disponible: Coque Tube v" + ver + " — reinstala desde la PC")
    end if
end sub

sub OnTubeUpdateError(event as Object)
    ' Sin manifiesto en GitHub Pages: un intento al servidor de casa.
    ' Si tampoco hay, la app sigue normal, sin aviso.
    if m.updateFallbackUsed = true then return
    m.updateFallbackUsed = true
    if m.updateTask <> invalid then m.updateTask.control = "STOP"
    t = CreateObject("roSGNode", "UpdateTask")
    if t = invalid then return
    t.url = "http://192.168.100.84:8766/coque-tube-roku-update.json"
    t.ObserveField("body", "OnTubeUpdateBody")
    t.ObserveField("error", "OnTubeUpdateError")
    m.updateTask = t
    t.control = "RUN"
end sub

function TubeCurrentVersion() as String
    info = CreateObject("roAppInfo")
    return info.GetValue("major_version") + "." + info.GetValue("minor_version") + "." + info.GetValue("build_version")
end function

function TubeVersionIsNewer(remote as String, current as String) as Boolean
    rParts = remote.Split(".")
    cParts = current.Split(".")
    n = rParts.Count()
    if cParts.Count() > n then n = cParts.Count()
    for i = 0 to n - 1
        r = 0 : c = 0
        if i < rParts.Count() then r = AsInt(rParts[i])
        if i < cParts.Count() then c = AsInt(cParts[i])
        if r > c then return true
        if r < c then return false
    end for
    return false
end function

function SafeStr(val as Dynamic) as String
    if val = invalid then return ""
    return val.ToStr()
end function

function AsInt(v as Dynamic) as Integer
    if v = invalid then return 0
    if Type(v) = "String" or Type(v) = "roString" then return Int(Val(v))
    return Int(v)
end function

function Tern(cond as Boolean, a as Dynamic, b as Dynamic) as Dynamic
    if cond then return a
    return b
end function
