sub init()
    m.top.functionName = "RunHistory"
end sub
sub RunHistory()
    sec = CreateObject("roRegistrySection", "CoqueTube")
    if sec = invalid
        m.top.error = "sin_registro"
        return
    end if
    op = m.top.op
    if op = "load"
        raw = sec.Read("history")
        if raw = invalid or raw = "" then raw = "[]"
        m.top.result = raw
        return
    end if
    if op = "save"
        item = ParseJSON(m.top.data)
        if item = invalid
            m.top.error = "sin_datos"
            return
        end if
        raw = sec.Read("history")
        list = []
        if raw <> invalid and raw <> ""
            parsed = ParseJSON(raw)
            if parsed <> invalid and Type(parsed) = "roArray" then list = parsed
        end if
        vid = ""
        if item.id <> invalid then vid = item.id.ToStr()
        cleaned = []
        for each old in list
            oid = ""
            if old <> invalid and Type(old) = "roAssociativeArray" and old.id <> invalid then oid = old.id.ToStr()
            if oid <> vid then cleaned.Push(old)
        end for
        cleaned.Unshift(item)
        while cleaned.Count() > 20
            cleaned.Pop()
        end while
        if sec.Write("history", FormatJSON(cleaned))
            sec.Flush()
            m.top.result = FormatJSON(cleaned)
        else
            m.top.error = "no_guardo"
        end if
        return
    end if
    m.top.error = "op_mala"
end sub
