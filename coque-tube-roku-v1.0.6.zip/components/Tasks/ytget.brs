sub init()
    m.top.functionName = "RunYt"
end sub
sub RunYt()
    url = m.top.url
    if url = invalid or url = "" then m.top.error = "sin_url" : return
    tout = m.top.timeout
    if tout = invalid or tout <= 0 then tout = 5000
    req = CreateObject("roUrlTransfer")
    req.SetUrl(url)
    req.AddHeader("Accept", "application/json")
    req.AddHeader("User-Agent", "Mozilla/5.0")
    req.EnableEncodings(true)
    req.SetCertificatesFile("common:/certs/ca-bundle.crt")
    req.InitClientCertificates()
    port = CreateObject("roMessagePort")
    req.SetMessagePort(port)
    if not req.AsyncGetToString()
        m.top.error = "async_fallo"
        return
    end if
    msg = wait(tout, port)
    if msg = invalid
        req.AsyncCancel()
        m.top.error = "timeout"
        return
    end if
    if type(msg) <> "roUrlEvent"
        m.top.error = "evento_inesperado"
        return
    end if
    code = msg.GetResponseCode()
    if code <> 200
        m.top.error = "http_" + code.ToStr()
        return
    end if
    m.top.response = msg.GetString()
end sub
